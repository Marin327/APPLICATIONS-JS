import { del, get, post, put } from "./api.js";

//1
const endpoints = {
    'albums': '/data/albums', // /data/albums си го виждаме от нашето условие като може да сменим и първото име
    'getAllAlbums' : "/data/albums?sortBy=_createdOn%20desc",
    "singleAlbum": "/data/albums/",
    // "search": "/data/albums?where=name"
}

export async function createAlbum(data) {
    return post(endpoints.albums, data)
};

export async function getAllAlbums() {
    return get(endpoints.getAllAlbums)
};

export async function getDetailsById(id) {
    return get(endpoints.singleAlbum + id);
}

export async function deleteAlbumById(id) {
    return del(endpoints.singleAlbum + id);
}

export async function updateAlbum(id, data) {
    return put(endpoints.singleAlbum + id, data)
};

// export async function searchAlbum(query) {
//     return get(`/data/albums?where=name%20LIKE%20%22${query}%22`)
// }

export async function likeAlbum(albumId) {
    return post('/data/likes', {
        albumId
    })
};

export async function getLikesByAlbumId(albumId){ // това е за likes ако имаме такъв бонус 
    return get(`/data/likes?where=albumId%3D%22${albumId}%22&distinct=_ownerId&count`)
};

export async function getMyLikesByAlbumId(albumId, userId) { // това е да показват книгите, които сме харесали
    return get(`/data/likes?where=albumId%3D%22${albumId}%22%20and%20_ownerId%3D%22${userId}%22&count`)
};