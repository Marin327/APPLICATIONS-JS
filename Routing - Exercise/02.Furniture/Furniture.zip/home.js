
function showHome(ctx) {
    ctx.render()
}
