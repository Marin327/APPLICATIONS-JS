import {get, post} from "./api.js";
import {clearUserData, setUserData} from "./users_store.js";

const endPoints = {
    login: '/users/login',
    register: '/users/register',
    logout: '/users/logout',
}

async function register(username, password) {
    const user = await post(endPoints.register, {username, password});
    setUserData(user);
}

async function login(username, password) {
    const user = await post(endPoints.login, {username, password});
    setUserData(user);
}

function logout() {
    get(endPoints.logout);
    clearUserData();
}

export {login, register, logout}
